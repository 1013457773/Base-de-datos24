package com.example.momento1.Servicios;

import com.example.momento1.modelos.Inscripcion;
import com.example.momento1.modelos.Usuario;
import com.example.momento1.repositorio.IUsuarioRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsuarioServicio {

    @Autowired
    IUsuarioRepositorio repositorio;

    public Usuario guardarUsuario(Usuario DatosUsuario)throws  Exception{
        try {
            return this.repositorio.save(DatosUsuario);
        }catch (Exception error){
            throw new Exception();
        }
    }


}
