package com.example.momento1.palabras;

public enum TipoUsuario {
    Estudiante,
    Docente
}
