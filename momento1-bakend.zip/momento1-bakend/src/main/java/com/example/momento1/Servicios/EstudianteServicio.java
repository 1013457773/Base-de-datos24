package com.example.momento1.Servicios;


import com.example.momento1.modelos.Estudiante;
import com.example.momento1.repositorio.IEstudianteRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EstudianteServicio {
    @Autowired
    IEstudianteRepositorio repositorio;

    public Estudiante guardarEstuduante(Estudiante DatosEstudiante)throws  Exception{
        try {
            return this.repositorio.save(DatosEstudiante);
        }catch (Exception error){
            throw new Exception();
        }
    }
}
