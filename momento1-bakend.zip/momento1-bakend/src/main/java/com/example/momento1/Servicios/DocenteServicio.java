package com.example.momento1.Servicios;


import com.example.momento1.modelos.Docente;
import com.example.momento1.repositorio.IDocenteRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DocenteServicio {

    @Autowired
    IDocenteRepositorio repositorio;

    public Docente guardarDocente(Docente DatosDocente)throws  Exception{
        try {
            return this.repositorio.save(DatosDocente);
        }catch (Exception error){
            throw new Exception();
        }
    }


}
