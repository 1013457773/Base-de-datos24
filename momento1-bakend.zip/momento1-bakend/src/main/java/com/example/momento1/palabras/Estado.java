package com.example.momento1.palabras;

public enum Estado {
    Ausente,
    Presemte,
    Justificado
}
