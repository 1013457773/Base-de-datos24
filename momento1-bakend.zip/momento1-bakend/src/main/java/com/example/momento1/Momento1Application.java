package com.example.momento1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Momento1Application {

	public static void main(String[] args) {
		SpringApplication.run(Momento1Application.class, args);
	}

}
